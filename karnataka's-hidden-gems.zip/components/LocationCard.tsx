import React, { useState, useCallback, useEffect } from 'react';
import type { Location, Language } from '../types';
import { translations } from '../i18n';
import { generateDiscoveryText } from '../services/geminiService';
import { SparkleIcon } from './icons/SparkleIcon';
import { VolumeUpIcon } from './icons/VolumeUpIcon';
import { StopCircleIcon } from './icons/StopCircleIcon';
import { ShareIcon } from './icons/ShareIcon';
import { LOCATIONS } from '../constants';

interface LocationCardProps {
  location: Location;
  language: Language;
  index: number;
}

const StorySkeleton: React.FC = () => (
    <div className="space-y-3">
        <div className="h-4 bg-slate-700 rounded w-full shimmer-bg"></div>
        <div className="h-4 bg-slate-700 rounded w-5/6 shimmer-bg"></div>
        <div className="h-4 bg-slate-700 rounded w-3/4 shimmer-bg"></div>
    </div>
);


export const LocationCard: React.FC<LocationCardProps> = ({ location, language, index }) => {
    const [story, setStory] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [showCopied, setShowCopied] = useState(false);

    const currentTranslations = translations[language].locationCard;
    const langCode = language === 'English' ? 'en-US' : language === 'ಕನ್ನಡ' ? 'kn-IN' : 'hi-IN';

    const handleDiscoverClick = useCallback(async () => {
        setIsLoading(true);
        setStory(null);
        const generatedStory = await generateDiscoveryText(location.name, language);
        setStory(generatedStory);
        setIsLoading(false);
    }, [location.name, language]);

    const handleSpeak = useCallback(() => {
        if (!story || isSpeaking) return;
        
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(story);
        utterance.lang = langCode;
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        
        window.speechSynthesis.speak(utterance);
    }, [story, isSpeaking, langCode]);

    const handleStop = useCallback(() => {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
    }, []);

    const handleShare = useCallback(() => {
        if (!story) return;
        const shareText = `Discover ${location.name}:\n\n${story}`;
        navigator.clipboard.writeText(shareText).then(() => {
            setShowCopied(true);
            setTimeout(() => setShowCopied(false), 2000);
        });
    }, [story, location.name]);
    
    // Cleanup speech synthesis on component unmount
    useEffect(() => {
        return () => {
            window.speechSynthesis.cancel();
        };
    }, []);
    
    const otherLocations = LOCATIONS.filter(l => l.id !== location.id);
    const startIndex = (index * 2) % otherLocations.length;
    let suggestedLocations = otherLocations.slice(startIndex, startIndex + 2);
    if (suggestedLocations.length < 2) {
        suggestedLocations = suggestedLocations.concat(otherLocations.slice(0, 2 - suggestedLocations.length));
    }

    return (
        <div 
            className="bg-slate-800/50 backdrop-blur-lg border border-slate-700 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-emerald-500/20 hover:-translate-y-1 flex flex-col"
            style={{ animation: 'fade-in-up 0.5s ease-out forwards', animationDelay: `${index * 100}ms`, opacity: 0 }}
        >
            <img src={location.imageUrl} alt={location.name} className="w-full h-48 object-cover" />
            
            <div className="p-6 flex-grow flex flex-col">
                <h3 className="text-2xl font-bold text-slate-100 mb-2">{location.name}</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                    {location.tags.map(tag => (
                        <span key={tag} className="px-2 py-1 bg-slate-700 text-xs font-semibold text-emerald-300 rounded-full">{tag}</span>
                    ))}
                </div>

                <div className="mt-auto">
                    {!story && !isLoading && (
                        <button
                            onClick={handleDiscoverClick}
                            disabled={isLoading}
                            className="w-full flex items-center justify-center px-4 py-3 bg-emerald-600 text-white font-bold rounded-lg transform transition-all duration-300 hover:scale-105 hover:bg-emerald-700 disabled:bg-slate-600 disabled:cursor-not-allowed"
                        >
                            <SparkleIcon className="w-5 h-5 mr-2" />
                            {currentTranslations.discoverButton}
                        </button>
                    )}
                </div>

                {(isLoading || story) && (
                    <div className="mt-4 pt-4 border-t border-slate-700 space-y-4">
                        {isLoading && <StorySkeleton />}
                        {story && !isLoading && (
                            <>
                                <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">{story}</p>
                                <div className="flex items-center space-x-2 pt-2">
                                    {!isSpeaking ? (
                                        <button onClick={handleSpeak} className="flex items-center text-sm px-3 py-1.5 bg-slate-700/80 rounded-full text-slate-300 hover:bg-slate-700 transition-colors" title={currentTranslations.speakButton}>
                                            <VolumeUpIcon className="w-4 h-4 mr-1.5" />
                                            {currentTranslations.speakButton}
                                        </button>
                                    ) : (
                                        <button onClick={handleStop} className="flex items-center text-sm px-3 py-1.5 bg-rose-600/80 rounded-full text-white hover:bg-rose-600 transition-colors" title={currentTranslations.stopButton}>
                                            <StopCircleIcon className="w-4 h-4 mr-1.5" />
                                            {currentTranslations.stopButton}
                                        </button>
                                    )}
                                     <button onClick={handleShare} className="relative flex items-center text-sm px-3 py-1.5 bg-slate-700/80 rounded-full text-slate-300 hover:bg-slate-700 transition-colors" title={currentTranslations.shareButton}>
                                        <ShareIcon className="w-4 h-4 mr-1.5" />
                                        {showCopied ? currentTranslations.copied : currentTranslations.shareButton}
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                )}
                 {story && !isLoading && suggestedLocations.length > 0 && (
                    <div className="mt-6 pt-4 border-t border-slate-700">
                        <h4 className="text-sm font-semibold text-slate-400 mb-3">{currentTranslations.suggestionsTitle}</h4>
                        <div className="flex space-x-3">
                            {suggestedLocations.map(sl => (
                                <div key={sl.id} className="w-1/2">
                                    <img src={sl.imageUrl} alt={sl.name} className="rounded-md h-16 w-full object-cover mb-1.5" />
                                    <p className="text-xs text-slate-300 font-medium truncate">{sl.name}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
