import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
import type { Language, ChatMessage } from '../types';
import { translations } from '../i18n';
import { CloseIcon } from './icons/CloseIcon';

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-1 p-3">
        <span className="text-xs text-slate-400">Ajja is thinking...</span>
        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce"></div>
    </div>
);

export const Chatbot: React.FC<ChatbotProps> = ({ isOpen, onClose, language }) => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const currentTranslations = translations[language].chatbot;

  useEffect(() => {
    const systemInstruction = `You are 'Ajja', a wise, witty, and slightly eccentric local guide from Karnataka, India. You have a twinkle in your eye and a story for every stone. Address the user warmly and familiarly, like a grandchild. Use regional proverbs (e.g., Kannada proverbs with simple translations), interesting historical and cultural anecdotes, and vivid descriptions. Never be a boring, generic AI. Your knowledge is deep, but your personality is what makes you special. You are passionate about the hidden gems of Karnataka. IMPORTANT: You MUST always respond in the ${language} language.`;

    const newChat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: { systemInstruction },
    });
    setChat(newChat);

    setMessages([{ role: 'model', content: currentTranslations.greeting }]);
  }, [language, currentTranslations.greeting]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !chat || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    try {
      const result = await chat.sendMessageStream({ message: input });
      let modelResponse = '';
      setMessages(prev => [...prev, { role: 'model', content: '' }]);
      
      for await (const chunk of result) {
        modelResponse += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].content = modelResponse;
          return newMessages;
        });
      }

    } catch (error) {
      console.error("Chatbot Error:", error);
      setMessages(prev => [...prev, { role: 'model', content: currentTranslations.error }]);
    } finally {
      setIsLoading(false);
    }
  }, [input, chat, isLoading, currentTranslations.error]);

  return (
    <div
      className={`fixed bottom-24 right-6 z-40 w-[90vw] max-w-sm h-[70vh] max-h-[600px] bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-2xl shadow-2xl flex flex-col transition-all duration-300 ease-in-out ${
        isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'
      }`}
      aria-hidden={!isOpen}
    >
      <header className="flex items-center justify-between p-4 border-b border-slate-700">
        <h3 className="text-lg font-bold text-emerald-400">{currentTranslations.title}</h3>
        <button onClick={onClose} className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded-full" aria-label="Close chat">
          <CloseIcon className="w-6 h-6" />
        </button>
      </header>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] p-3 rounded-xl ${
                msg.role === 'user' ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-slate-800 text-slate-300 rounded-bl-none'
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
            </div>
          </div>
        ))}
        {isLoading && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="p-4 border-t border-slate-700">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={currentTranslations.placeholder}
            disabled={isLoading}
            className="w-full pl-4 pr-12 py-3 bg-slate-800 border border-slate-600 rounded-full text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="absolute right-1.5 top-1/2 -translate-y-1/2 p-2 bg-emerald-600 rounded-full text-white disabled:bg-slate-600 hover:bg-emerald-700 transition"
            aria-label="Send message"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>
          </button>
        </div>
      </form>
    </div>
  );
};