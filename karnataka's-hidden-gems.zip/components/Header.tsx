import React from 'react';
import { LanguageSelector } from './LanguageSelector';
import type { Language } from '../types';

interface HeaderProps {
    language: Language;
    onLanguageChange: (lang: Language) => void;
    translations: {
        title: string;
        subtitle: string;
    }
}

export const Header: React.FC<HeaderProps> = ({ language, onLanguageChange, translations }) => {
  return (
    <header className="relative text-center py-12 px-4 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-20">
      <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500 mb-2">
        {translations.title}
      </h1>
      <p className="text-md md:text-lg text-slate-400 max-w-2xl mx-auto">
        {translations.subtitle}
      </p>
      <LanguageSelector selectedLanguage={language} onSelectLanguage={onLanguageChange} />
    </header>
  );
};
