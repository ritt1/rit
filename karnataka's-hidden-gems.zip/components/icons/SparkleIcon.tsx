
import React from 'react';

export const SparkleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    {...props}
  >
    <path d="M12 3L9.27 9.27L3 12L9.27 14.73L12 21L14.73 14.73L21 12L14.73 9.27L12 3Z" />
    <path d="M5 3V7" />
    <path d="M19 17V21" />
    <path d="M3 17H7" />
    <path d="M17 3H21" />
  </svg>
);
