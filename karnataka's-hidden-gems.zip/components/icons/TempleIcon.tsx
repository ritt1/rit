import React from 'react';

export const TempleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M3.5 13.5A2.5 2.5 0 0 1 6 11h12a2.5 2.5 0 0 1 2.5 2.5v6.5H3.5v-6.5Z" />
    <path d="M6 11V3.5a2.5 2.5 0 0 1 .4-1.3l3-4a.5.5 0 0 1 .8 0l3 4a2.5 2.5 0 0 1 .4 1.3V11" />
    <path d="M18 11V3.5a2.5 2.5 0 0 0-.4-1.3l-3-4a.5.5 0 0 0-.8 0l-3 4a2.5 2.5 0 0 0-.4 1.3V11" />
    <path d="M10 20v-5a2 2 0 0 1 4 0v5" />
  </svg>
);
