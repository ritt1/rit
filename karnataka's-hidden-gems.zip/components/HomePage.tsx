import React, { useMemo } from 'react';
import { LOCATIONS } from '../constants';
import { LocationCard } from './LocationCard';
import { translations } from '../i18n';
import type { Language } from '../types';

interface HomePageProps {
    onShowAll: () => void;
    language: Language;
}

export const HomePage: React.FC<HomePageProps> = ({ onShowAll, language }) => {
    // Pick a consistent featured location based on the day, so it doesn't change on every render
    const featuredLocation = useMemo(() => {
        const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
        return LOCATIONS[dayOfYear % LOCATIONS.length];
    }, []);

    const currentTranslations = translations[language].home;

    return (
        <div className="flex flex-col items-center text-center animate-fade-in-up pt-8">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">{currentTranslations.title}</h2>
            <p className="text-lg text-slate-400 max-w-3xl mx-auto mb-12">{currentTranslations.subtitle}</p>

            <div className="mb-12 w-full max-w-md transform transition-transform duration-500 hover:scale-105">
                 <h3 className="text-2xl font-semibold text-emerald-400 mb-6">{currentTranslations.featuredTitle}</h3>
                <LocationCard location={featuredLocation} language={language} index={0} />
            </div>

            <button
                onClick={onShowAll}
                className="px-8 py-4 bg-emerald-600 text-white font-bold rounded-full text-lg transform transition-all duration-300 hover:scale-105 hover:bg-emerald-700 hover:shadow-2xl hover:shadow-emerald-600/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/50"
            >
                {currentTranslations.button}
            </button>
        </div>
    )
}