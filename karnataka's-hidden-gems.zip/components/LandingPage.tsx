import React from 'react';
import type { Language } from '../types';
import { translations } from '../i18n';
import { CultureIcon } from './icons/CultureIcon';
import { LeafIcon } from './icons/LeafIcon';
import { TempleIcon } from './icons/TempleIcon';

interface LandingPageProps {
  onExplore: () => void;
  language: Language;
}

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string; delay: string }> = ({ icon, title, description, delay }) => (
    <div className="bg-slate-800/50 backdrop-blur-lg border border-slate-700 rounded-2xl p-6 text-center transform transition-all duration-300 hover:shadow-emerald-500/20 hover:-translate-y-1 animate-fade-in-up" style={{ animationDelay: delay }}>
        <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 bg-emerald-900/50 rounded-full border border-emerald-700 text-emerald-400">
            {icon}
        </div>
        <h3 className="text-xl font-bold text-slate-100 mb-2">{title}</h3>
        <p className="text-slate-400">{description}</p>
    </div>
);

export const LandingPage: React.FC<LandingPageProps> = ({ onExplore, language }) => {
  const currentTranslations = translations[language].landing;
  const headerTranslations = translations[language].header;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-sans antialiased overflow-x-hidden">
      <div className="absolute inset-0 bg-grid-slate-800 [mask-image:linear-gradient(to_bottom,white_20%,transparent_100%)]"></div>
      <div className="relative container mx-auto px-4 py-16 md:py-24 flex flex-col items-center text-center">
        
        <div className="animate-fade-in-up">
            <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500 mb-4">
                {headerTranslations.title}
            </h1>
            <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto mb-12">
                {currentTranslations.subtitle}
            </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 w-full max-w-5xl">
            <FeatureCard 
                icon={<TempleIcon className="w-8 h-8" />} 
                title={currentTranslations.feature1Title} 
                description={currentTranslations.feature1Desc}
                delay="200ms"
            />
            <FeatureCard 
                icon={<LeafIcon className="w-8 h-8" />} 
                title={currentTranslations.feature2Title} 
                description={currentTranslations.feature2Desc}
                delay="400ms"
            />
            <FeatureCard 
                icon={<CultureIcon className="w-8 h-8" />} 
                title={currentTranslations.feature3Title} 
                description={currentTranslations.feature3Desc}
                delay="600ms"
            />
        </div>
        
        <div className="animate-fade-in-up" style={{ animationDelay: '800ms' }}>
            <button
                onClick={onExplore}
                className="px-10 py-5 bg-emerald-600 text-white font-bold rounded-full text-xl transform transition-all duration-300 hover:scale-105 hover:bg-emerald-700 hover:shadow-2xl hover:shadow-emerald-600/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/50"
            >
                {currentTranslations.button}
            </button>
        </div>
      </div>
      <style>{`
        .bg-grid-slate-800 {
            background-image: linear-gradient(0deg, transparent 24%, rgba(255, 255, 255, 0.05) 25%, rgba(255, 255, 255, 0.05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, 0.05) 75%, rgba(255, 255, 255, 0.05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(255, 255, 255, 0.05) 25%, rgba(255, 255, 255, 0.05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, 0.05) 75%, rgba(255, 255, 255, 0.05) 76%, transparent 77%, transparent);
            background-size: 50px 50px;
        }
        @keyframes fade-in-up {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
};
