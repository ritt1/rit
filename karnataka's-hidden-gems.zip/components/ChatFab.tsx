import React from 'react';
import { ChatIcon } from './icons/ChatIcon';
import { CloseIcon } from './icons/CloseIcon';

interface ChatFabProps {
  onClick: () => void;
  isOpen: boolean;
}

export const ChatFab: React.FC<ChatFabProps> = ({ onClick, isOpen }) => {
  return (
    <button
      onClick={onClick}
      aria-label={isOpen ? "Close travel guide chat" : "Open travel guide chat"}
      className="fixed bottom-6 right-6 z-50 w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-lg transform transition-all duration-300 hover:scale-110 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-emerald-500"
    >
      <div className="relative w-8 h-8">
        <ChatIcon className={`absolute inset-0 transition-all duration-300 ${isOpen ? 'transform rotate-90 opacity-0' : 'transform rotate-0 opacity-100'}`} />
        <CloseIcon className={`absolute inset-0 transition-all duration-300 ${isOpen ? 'transform rotate-0 opacity-100' : 'transform -rotate-90 opacity-0'}`} />
      </div>
    </button>
  );
};