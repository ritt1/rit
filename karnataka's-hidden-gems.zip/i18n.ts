import type { Language } from './types';

type Translations = {
  [key in Language]: {
    header: {
      title: string;
      subtitle: string;
    };
    landing: {
      title: string;
      subtitle: string;
      button: string;
      feature1Title: string;
      feature1Desc: string;
      feature2Title: string;
      feature2Desc: string;
      feature3Title: string;
      feature3Desc: string;
    };
    home: {
      title: string;
      subtitle: string;
      featuredTitle: string;
      button: string;
    };
    backButton: {
      text: string;
      ariaLabel: string;
    };
    footer: {
      text: string;
    };
    locationCard: {
      discoverButton: string;
      suggestionsTitle: string;
      speakButton: string;
      stopButton: string;
      shareButton: string;
      copied: string;
    };
    chatbot: {
      title: string;
      greeting: string;
      placeholder: string;
      error: string;
    };
  };
};

export const translations: Translations = {
  English: {
    header: {
      title: 'Explore Hidden Gems in Karnataka',
      subtitle: 'Discover the hidden gems and untold stories of India\'s most diverse state.'
    },
    landing: {
      title: 'Journey Through the Soul of Karnataka',
      subtitle: 'From ancient ruins to misty hills, a land of wonders awaits. Your personal AI guide to the heart of Southern India.',
      button: 'Start Exploring',
      feature1Title: 'Ancient Mysteries',
      feature1Desc: 'Uncover the stories whispered by the stones of Hampi and Badami.',
      feature2Title: 'Lush Sanctuaries',
      feature2Desc: 'Find serenity in the verdant coffee plantations and rolling hills of Coorg and Chikmagalur.',
      feature3Title: 'Coastal Wonders',
      feature3Desc: 'Feel the ocean breeze and discover the spiritual aura of Gokarna and Udupi.',
    },
    home: {
        title: 'Welcome, Traveler!',
        subtitle: 'Let\'s begin our journey. Discover a special place below, or explore all the wonders Karnataka has to offer.',
        featuredTitle: 'Gem of the Day',
        button: 'Explore All Destinations'
    },
    backButton: {
      text: 'Back',
      ariaLabel: 'Go back to the previous page',
    },
    footer: {
      text: '© 2024 Karnataka Unveiled. All rights reserved. A journey into the heart of India.'
    },
    locationCard: {
      discoverButton: 'Discover the Story',
      suggestionsTitle: 'You might also like:',
      speakButton: 'Speak',
      stopButton: 'Stop',
      shareButton: 'Share',
      copied: 'Copied!'
    },
    chatbot: {
      title: 'Ask Ajja',
      greeting: 'Namaskara! I am Ajja, your wise old guide to Karnataka. What tales can I tell you today, my child?',
      placeholder: 'Ask about places, food, or stories...',
      error: 'Ah, my old mind is a bit fuzzy. I couldn\'t fetch that. Please try asking again.'
    }
  },
  'ಕನ್ನಡ': {
    header: {
      title: 'ಕರ್ನಾಟಕದ ಗುಪ್ತ ರತ್ನಗಳನ್ನು ಅನ್ವೇಷಿಸಿ',
      subtitle: 'ಭಾರತದ ಅತ್ಯಂತ ವೈವಿಧ್ಯಮಯ ರಾಜ್ಯದ ಗುಪ್ತ ರತ್ನಗಳು ಮತ್ತು ಹೇಳದ ಕಥೆಗಳನ್ನು ಅನ್ವೇಷಿಸಿ.'
    },
    landing: {
      title: 'ಕರ್ನಾಟಕದ ಆತ್ಮದ ಮೂಲಕ ಪ್ರಯಾಣ',
      subtitle: 'ಪ್ರಾಚೀನ ಅವಶೇಷಗಳಿಂದ ಹಿಡಿದು ಮಂಜಿನ ಬೆಟ್ಟಗಳವರೆಗೆ, ಅದ್ಭುತಗಳ ನಾಡು ಕಾಯುತ್ತಿದೆ. ದಕ್ಷಿಣ ಭಾರತದ ಹೃದಯಕ್ಕೆ ನಿಮ್ಮ ವೈಯಕ್ತಿಕ AI ಮಾರ್ಗದರ್ಶಿ.',
      button: 'ಅನ್ವೇಷಣೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿ',
      feature1Title: 'ಪ್ರಾಚೀನ ರಹಸ್ಯಗಳು',
      feature1Desc: 'ಹಂಪಿ ಮತ್ತು ಬಾದಾಮಿಯ ಕಲ್ಲುಗಳು ಪಿಸುಗುಟ್ಟುವ ಕಥೆಗಳನ್ನು ಬಹಿರಂಗಪಡಿಸಿ.',
      feature2Title: 'ಹಚ್ಚ ಹಸಿರಿನ ಅಭಯಾರಣ್ಯಗಳು',
      feature2Desc: 'ಕೊಡಗು ಮತ್ತು ಚಿಕ್ಕಮಗಳೂರಿನ ಹಚ್ಚ ಹಸಿರಿನ ಕಾಫಿ ತೋಟಗಳು ಮತ್ತು ಉರುಳುವ ಬೆಟ್ಟಗಳಲ್ಲಿ ಪ್ರಶಾಂತತೆಯನ್ನು ಕಂಡುಕೊಳ್ಳಿ.',
      feature3Title: 'ಕರಾವಳಿ ಅದ್ಭುತಗಳು',
      feature3Desc: 'ಸಮುದ್ರದ ತಂಗಾಳಿಯನ್ನು ಅನುಭವಿಸಿ ಮತ್ತು ಗೋಕರ್ಣ ಮತ್ತು ಉಡುಪಿಯ ಆಧ್ಯಾತ್ಮಿಕ ಸೆಳವನ್ನು ಅನ್ವೇಷಿಸಿ.',
    },
    home: {
        title: 'ಸ್ವಾಗತ, ಪ್ರಯಾಣಿಕರೇ!',
        subtitle: 'ನಮ್ಮ ಪ್ರಯಾಣವನ್ನು ಪ್ರಾರಂಭಿಸೋಣ. ಕೆಳಗೆ ಒಂದು ವಿಶೇಷ ಸ್ಥಳವನ್ನು ಅನ್ವೇಷಿಸಿ, ಅಥವಾ ಕರ್ನಾಟಕ ನೀಡುವ ಎಲ್ಲಾ ಅದ್ಭುತಗಳನ್ನು ಅನ್ವೇಷಿಸಿ.',
        featuredTitle: 'ದಿನದ ರತ್ನ',
        button: 'ಎಲ್ಲಾ ಗಮ್ಯಸ್ಥಾನಗಳನ್ನು ಅನ್ವೇಷಿಸಿ'
    },
    backButton: {
      text: 'ಹಿಂದೆ',
      ariaLabel: 'ಹಿಂದಿನ ಪುಟಕ್ಕೆ ಹಿಂತಿರುಗಿ',
    },
    footer: {
      text: '© 2024 ಕರ್ನಾಟಕ ಅನಾವರಣ. ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ. ಭಾರತದ ಹೃದಯಕ್ಕೆ ಒಂದು ಪ್ರಯಾಣ.'
    },
    locationCard: {
      discoverButton: 'ಕಥೆಯನ್ನು ಅನ್ವೇಷಿಸಿ',
      suggestionsTitle: 'ನೀವು ಇದನ್ನು ಇಷ್ಟಪಡಬಹುದು:',
      speakButton: 'ಮಾತನಾಡಿ',
      stopButton: 'ನಿಲ್ಲಿಸಿ',
      shareButton: 'ಹಂಚಿಕೊಳ್ಳಿ',
      copied: 'ನಕಲಿಸಲಾಗಿದೆ!'
    },
    chatbot: {
      title: 'ಅಜ್ಜ ಅವರನ್ನು ಕೇಳಿ',
      greeting: 'ನಮಸ್ಕಾರ! ನಾನು ಅಜ್ಜ, ಕರ್ನಾಟಕಕ್ಕೆ ನಿಮ್ಮ ಜ್ಞಾನಿ ಹಳೆಯ ಮಾರ್ಗದರ್ಶಿ. ಇಂದು ನಾನು ನಿಮಗೆ ಯಾವ ಕಥೆಗಳನ್ನು ಹೇಳಲಿ, ಮಗುವೇ?',
      placeholder: 'ಸ್ಥಳಗಳು, ಆಹಾರ, ಅಥವಾ ಕಥೆಗಳ ಬಗ್ಗೆ ಕೇಳಿ...',
      error: 'ಅಯ್ಯೋ, ನನ್ನ ಹಳೆಯ ಮನಸ್ಸು ಸ್ವಲ್ಪ ಮಬ್ಬಾಗಿದೆ. ನನಗೆ ಅದನ್ನು ತರಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೊಮ್ಮೆ ಕೇಳಲು ಪ್ರಯತ್ನಿಸಿ.'
    }
  },
  'हिन्दी': {
    header: {
      title: 'कर्नाटक के छिपे रत्नों का अन्वेषण करें',
      subtitle: 'भारत के सबसे विविध राज्य के छिपे हुए रत्नों और अनकही कहानियों की खोज करें।'
    },
    landing: {
      title: 'कर्नाटक की आत्मा के माध्यम से यात्रा',
      subtitle: 'प्राचीन खंडहरों से लेकर धुंध भरी पहाड़ियों तक, चमत्कारों की भूमि इंतजार कर रही है। दक्षिण भारत के हृदय के लिए आपका व्यक्तिगत AI गाइड।',
      button: 'अन्वेषण शुरू करें',
      feature1Title: 'प्राचीन रहस्य',
      feature1Desc: 'हम्पी और बादामी के पत्थरों द्वारा फुसफुसाई गई कहानियों को उजागर करें।',
      feature2Title: 'हरे-भरे अभयारण्य',
      feature2Desc: 'कूर्ग और चिकमंगलूर के हरे-भरे कॉफी बागानों और घुमावदार पहाड़ियों में शांति पाएं।',
      feature3Title: 'तटीय चमत्कार',
      feature3Desc: 'समुद्र की हवा को महसूस करें और गोकर्ण और उडुपी की आध्यात्मिक आभा की खोज करें।',
    },
    home: {
        title: 'स्वागत है, यात्री!',
        subtitle: 'आइए अपनी यात्रा शुरू करें। नीचे एक विशेष स्थान की खोज करें, या कर्नाटक द्वारा प्रदान किए जाने वाले सभी आश्चर्यों का पता लगाएं।',
        featuredTitle: 'दिन का रत्न',
        button: 'सभी गंतव्यों का अन्वेषण करें'
    },
    backButton: {
      text: 'वापस',
      ariaLabel: 'पिछले पृष्ठ पर वापस जाएं',
    },
    footer: {
      text: '© 2024 कर्नाटक अनावरण। सर्वाधिकार सुरक्षित। भारत के हृदय में एक यात्रा।'
    },
    locationCard: {
      discoverButton: 'कहानी खोजें',
      suggestionsTitle: 'आपको यह भी पसंद आ सकता है:',
      speakButton: 'बोलें',
      stopButton: 'रोकें',
      shareButton: 'साझा करें',
      copied: 'कॉपी किया गया!'
    },
    chatbot: {
      title: 'अज्जा से पूछें',
      greeting: 'नमस्कार! मैं अज्जा हूं, कर्नाटक के लिए आपका बुद्धिमान पुराना गाइड। आज मैं आपको कौन सी कहानियां सुना सकता हूं, मेरे बच्चे?',
      placeholder: 'स्थानों, भोजन, या कहानियों के बारे में पूछें...',
      error: 'आह, मेरा पुराना दिमाग थोड़ा धुंधला है। मैं वह नहीं ला सका। कृपया फिर से पूछने का प्रयास करें।'
    }
  }
};