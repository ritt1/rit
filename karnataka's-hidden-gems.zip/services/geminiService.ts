import { GoogleGenAI } from "@google/genai";
import type { Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDiscoveryText = async (locationName: string, language: Language): Promise<string> => {
  try {
    const prompt = `You are a poetic travel writer. Describe the hidden gem of "${locationName}" in Karnataka. Focus on its untouched natural wonders, history, and culture. Evoke wonder and adventure. Keep it to two immersive paragraphs.
IMPORTANT: Write the entire response in the ${language} language.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error generating text from Gemini API:", error);
    return "Could not retrieve the story of this place. Please try again later.";
  }
};