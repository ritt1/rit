export type Language = 'English' | 'ಕನ್ನಡ' | 'हिन्दी';

export interface Location {
  id: string;
  name: string;
  imageUrl: string;
  tags: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
