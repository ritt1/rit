import React, { useState } from 'react';
import { Header } from './components/Header';
import { LocationCard } from './components/LocationCard';
import { Chatbot } from './components/Chatbot';
import { ChatFab } from './components/ChatFab';
import { LandingPage } from './components/LandingPage';
import { HomePage } from './components/HomePage';
import { LOCATIONS } from './constants';
import type { Location, Language } from './types';
import { translations } from './i18n';
import { ArrowLeftIcon } from './components/icons/ArrowLeftIcon';

type View = 'landing' | 'home' | 'all_locations';

const App: React.FC = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [view, setView] = useState<View>('landing');
  const [language, setLanguage] = useState<Language>('English');

  const handleExplore = () => {
    setView('home');
  };

  const handleShowAll = () => {
    setView('all_locations');
  };
  
  const handleBack = () => {
    if (view === 'all_locations') {
      setView('home');
    } else if (view === 'home') {
      setView('landing');
    }
  };

  const toggleChat = () => {
    setIsChatOpen(prev => !prev);
  };

  if (view === 'landing') {
    return <LandingPage onExplore={handleExplore} language={language} />;
  }

  const currentTranslations = translations[language];

  return (
    <div className="min-h-screen bg-slate-900/70 text-slate-200 font-sans antialiased backdrop-blur-sm">
      <Header 
        language={language}
        onLanguageChange={setLanguage}
        translations={currentTranslations.header}
      />
      <main className="container mx-auto px-4 py-8 relative">
        {(view === 'home' || view === 'all_locations') && (
            <button
                onClick={handleBack}
                className="absolute top-[-1rem] left-4 md:left-0 z-10 flex items-center px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-full text-slate-300 hover:bg-slate-700 transition-colors mb-4"
                aria-label={currentTranslations.backButton.ariaLabel}
            >
                <ArrowLeftIcon className="w-5 h-5 mr-2" />
                {currentTranslations.backButton.text}
            </button>
        )}
        {view === 'home' && <HomePage onShowAll={handleShowAll} language={language} />}
        {view === 'all_locations' && (
          <div className="pt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {LOCATIONS.map((location: Location, index: number) => (
              <LocationCard 
                key={location.id} 
                location={location} 
                language={language}
                index={index}
              />
            ))}
          </div>
        )}
      </main>
      <footer className="text-center py-6 text-slate-300 text-sm">
        <p>{currentTranslations.footer.text}</p>
      </footer>
      
      <ChatFab onClick={toggleChat} isOpen={isChatOpen} />
      <Chatbot 
        isOpen={isChatOpen} 
        onClose={() => setIsChatOpen(false)} 
        language={language} 
      />
      <style>{`
        @keyframes fade-in-up {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
        @keyframes shimmer-animation {
          0% { background-position: 100% 0; }
          100% { background-position: -100% 0; }
        }
        .shimmer-bg {
          background-image: linear-gradient(
            to right,
            rgba(51, 65, 85, 1) 0%,
            rgba(71, 85, 105, 1) 20%,
            rgba(51, 65, 85, 1) 40%,
            rgba(51, 65, 85, 1) 100%
          );
          background-size: 200% 100%;
          animation: shimmer-animation 1.5s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default App;